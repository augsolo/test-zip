import manifest from "@/data/clothesManifest.json";
import type { Season, Outfit } from "@/types";

const seasonRules: Record<Season, string[]> = {
  spring: ["tshirts", "light-jacket", "pants", "sneakers"],
  summer: ["tshirts", "shorts", "sandals"],
  autumn: ["tshirts", "light-jacket", "pants", "sneakers"],
  winter: ["jumper-hoodies", "strong-jacket", "pants", "boots"]
};

function pickRandom<T>(arr: T[]): T | null {
  if (!arr.length) return null;
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateOutfitForSeason(season: Season): Outfit {
  const categories = seasonRules[season];
  const outfit: Outfit = {};

  for (const cat of categories) {
    const files = (manifest as Record<string, string[]>)[cat] || [];
    const file = pickRandom(files);

    if (file) {
      outfit[cat] = {
        category: cat,
        file,
        path: `/clothes/${cat}/${file}`
      };
    }
  }

  return outfit;
}
