import React from "react";
import { useVestiumStore } from "@/store/useVestiumStore";
import type { Season } from "@/types";

export const SeasonSelector: React.FC = () => {
  const season = useVestiumStore((s) => s.season);
  const setSeason = useVestiumStore((s) => s.setSeason);

  return (
    <select
      className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-sm"
      value={season}
      onChange={(e) => setSeason(e.target.value as Season)}
    >
      <option value="spring">Spring</option>
      <option value="summer">Summer</option>
      <option value="autumn">Autumn</option>
      <option value="winter">Winter</option>
    </select>
  );
};

