import React from "react";
import type { Outfit } from "@/types";

type Props = {
  outfit: Outfit | null;
}

export const OutfitGrid: React.FC<Props> = ({ outfit }) => {
  if (!outfit) {
    return <div className="text-slate-400">No outfit for this day.</div>;
  }

  const items = Object.values(outfit);

  return (
    <div className="grid grid-cols-2 grid-rows-3 gap-4 mt-4">
      {items.map((item) => (
        <div
          key={item.path}
          className="bg-slate-800 rounded-lg p-2 flex flex-col items-center"
        >
          <div className="text-xs text-slate-300">{item.category}</div>
          <img src={item.path} className="max-h-32 object-contain" />
        </div>
      ))}
    </div>
  );
};

