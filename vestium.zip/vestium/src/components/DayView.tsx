import React from "react";
import { useVestiumStore } from "@/store/useVestiumStore";
import { OutfitGrid } from "./OutfitGrid";
import { SeasonSelector } from "./SeasonSelector";

export const DayView: React.FC = () => {
  const selectedDate = useVestiumStore((s) => s.selectedDate);
  const outfits = useVestiumStore((s) => s.outfits);

  const entry = outfits[selectedDate] || null;

  return (
    <div className="bg-slate-800 p-4 rounded-lg">
      <div className="flex justify-between">
        <div>
          <div className="text-lg font-bold">{selectedDate}</div>
          {entry && (
            <div className="text-xs text-slate-400">
              Season: {entry.season}
            </div>
          )}
        </div>
        <SeasonSelector />
      </div>

      <OutfitGrid outfit={entry?.outfit ?? null} />
    </div>
  );
};
