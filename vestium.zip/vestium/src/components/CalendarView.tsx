import React from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { useVestiumStore } from "@/store/useVestiumStore";

function toISO(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export const CalendarView: React.FC = () => {
  const selectedDate = useVestiumStore((s) => s.selectedDate);
  const setSelectedDate = useVestiumStore((s) => s.setSelectedDate);
  const outfits = useVestiumStore((s) => s.outfits);

  return (
    <div className="bg-slate-800 rounded-lg p-4 shadow-md">
      <Calendar
        onChange={(value) => setSelectedDate(toISO(value as Date))}
        value={new Date(selectedDate)}
        tileClassName={({ date }) =>
          outfits[toISO(date)] ? "has-outfit" : undefined
        }
      />
    </div>
  );
};

