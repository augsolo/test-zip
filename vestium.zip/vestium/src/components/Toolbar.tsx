import React from "react";
import { useVestiumStore } from "@/store/useVestiumStore";

export const Toolbar: React.FC = () => {
  const selectedDate = useVestiumStore((s) => s.selectedDate);
  const generateForToday = useVestiumStore((s) => s.generateForToday);
  const generateForDate = useVestiumStore((s) => s.generateForDate);
  const deleteForDate = useVestiumStore((s) => s.deleteForDate);
  const saveCurrent = useVestiumStore((s) => s.saveCurrent);

  return (
    <div className="flex gap-2">
      <button onClick={generateForToday} className="btn-green">
        Generate Today
      </button>
      <button onClick={() => generateForDate(selectedDate)} className="btn-blue">
        Generate Selected
      </button>
      <button onClick={saveCurrent} className="btn-yellow">
        Save
      </button>
      <button onClick={() => deleteForDate(selectedDate)} className="btn-red">
        Delete
      </button>
    </div>
  );
};
