import { create } from "zustand";
import type { DB, Season } from "@/types";
import { loadDB, saveDB } from "@/utils/db";
import { generateOutfitForSeason } from "@/utils/outfitGenerator";

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

type VestiumState = {
  selectedDate: string;
  season: Season;
  outfits: DB;

  setSelectedDate: (date: string) => void;
  setSeason: (season: Season) => void;

  generateForDate: (date: string) => void;
  generateForToday: () => void;

  deleteForDate: (date: string) => void;
  saveCurrent: () => void;
}

export const useVestiumStore = create<VestiumState>((set, get) => ({
  selectedDate: todayISO(),
  season: "spring",
  outfits: loadDB(),

  setSelectedDate: (date) => set({ selectedDate: date }),
  setSeason: (season) => set({ season }),

  generateForDate: (date) => {
    const { season, outfits } = get();
    const outfit = generateOutfitForSeason(season);

    const updated: DB = {
      ...outfits,
      [date]: { season, outfit }
    };

    saveDB(updated);
    set({ outfits: updated });
  },

  generateForToday: () => {
    const date = todayISO();
    get().generateForDate(date);
    set({ selectedDate: date });
  },

  deleteForDate: (date) => {
    const { outfits } = get();
    const updated = { ...outfits };
    delete updated[date];
    saveDB(updated);
    set({ outfits: updated });
  },

  saveCurrent: () => {
    const { outfits } = get();
    saveDB(outfits);
  }
}));
