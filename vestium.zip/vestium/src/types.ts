export type Season = "spring" | "summer" | "autumn" | "winter";

export interface ClothingItem {
  category: string;
  file: string;
  path: string;
}

export type Outfit = Record<string, ClothingItem>;

export interface DayEntry {
  season: Season;
  outfit: Outfit;
}

export type DB = Record<string, DayEntry>;
