import React from "react";
import { CalendarView } from "@/components/CalendarView";
import { DayView } from "@/components/DayView";
import { Toolbar } from "@/components/Toolbar";

export const App: React.FC = () => {
  return (
    <div className="p-4 max-w-6xl mx-auto">
      <Toolbar />
      <div className="flex gap-4 mt-4">
        <div className="w-1/3">
          <CalendarView />
        </div>
        <div className="w-2/3">
          <DayView />
        </div>
      </div>
    </div>
  );
};

export default App;
