import { readdirSync, writeFileSync, statSync } from "fs";
import { join } from "path";

const CLOTHES_DIR = join(process.cwd(), "public", "clothes");
const OUTPUT_FILE = join(process.cwd(), "src", "data", "clothesManifest.json");

function generateManifest() {
  const categories = readdirSync(CLOTHES_DIR);

  const manifest: Record<string, string[]> = {};

  for (const category of categories) {
    const categoryPath = join(CLOTHES_DIR, category);

    if (!statSync(categoryPath).isDirectory()) continue;

    const files = readdirSync(categoryPath).filter((file) => {
      return /\.(png|jpg|jpeg|webp|gif)$/i.test(file);
    });

    manifest[category] = files;
  }

  writeFileSync(OUTPUT_FILE, JSON.stringify(manifest, null, 2));
  console.log("Manifest generated:", OUTPUT_FILE);
}

generateManifest();

// run this script like:
//npx ts-node scripts/generateManifest.ts

